INSERT INTO attraction (nom, description, difficulte, visible) VALUES ('Silver Star', 'Montagne russe', 3, 1);
INSERT INTO attraction (nom, description, difficulte, visible) VALUES ('Montagne 8', 'Montagne russe', 4, 1);


INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (1,"Lucas","PLATEAU","J'adore monter dans l'attraction Tobias",2,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (1,"Lucas","PLATEAU","C'était super !",4,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (1,"Lucas","PLATEAU","C'était super !",4,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (1,"Lucas","PLATEAU","C'était super !",4,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (1,"Lucas","PLATEAU","C'était super !",4,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (1,"Lucas","PLATEAU","C'était super !",4,0);

INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (2,"Lucas","PLATEAU","C'était super !",3,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (2,"Lucas","PLATEAU","C'était super !",3,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (2,"Lucas","PLATEAU","NIRVANAAAAAAA",2,0);
INSERT INTO critique (attraction_id,name,first_name,text,mark,isAnonym) VALUES (2,"Lucas","PLATEAU","Bof enfaite",1,0);

INSERT INTO users (name, password) VALUES ('toto', 'toto');